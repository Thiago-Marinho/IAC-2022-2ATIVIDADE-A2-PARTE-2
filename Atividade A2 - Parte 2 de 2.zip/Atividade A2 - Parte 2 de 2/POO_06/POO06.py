from Pedido import Pedido
from Produto import Produto
from Item import Item

itens = []
P1 = Produto("Coca", 5, 15)

itens.append(["Coca", 5, 3])
itens.append(["fanta", 5, 3])
itens.append(["Coca Zero", 5, 3])
itens.append(["Coca Cafe", 10, 3])
itens.append(["Coca Cola", 5, 3])

Ped = Pedido(1, "pix", itens)
print(Pedido.visualizarPedidoLista(Ped))




