class Produto:

    def __init__(self, nome: str, preco: float, quantidadeEstoque: int):
        self.nome = nome
        self.preco = preco
        self.quantidadeEstoque = quantidadeEstoque