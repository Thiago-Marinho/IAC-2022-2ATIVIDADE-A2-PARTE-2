from Produto import Produto
from Item import Item
class Pedido:
    global itens
    itens = []

    def __init__(self, codigoPedido, formaPagamento, item: Item):
        self.codigoPedido = codigoPedido
        self.formaPagamento = formaPagamento
        self.itens = item


    def adicionarItemLista(self, item):
        self.itens.append(item)

    def visualizarItemLista(self):
        return self.itens


    def visualizarPedidoLista(self):
        i = 0
        print("Codigo: " + str(self.codigoPedido), "Forma Pagamento: " + self.formaPagamento)
        for list in self.itens:
            print("Produto: " + list[i], " - Valor: R$" + str(list[i+1]), " - Quantidade: " + str(list[i+2]))
        i+1
