from Produto import Produto
class Item(Produto):


    def __init__(self, nomeProduto ,preco, quantidadeProduto):
        super().__init__(self, nomeProduto,preco)
        self.quantidadeProduto = quantidadeProduto

