from Arvore import arvoreGenealogica

arvore = arvoreGenealogica()