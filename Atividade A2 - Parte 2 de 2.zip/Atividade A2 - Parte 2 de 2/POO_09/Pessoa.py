class Pessoa:
    def __init__(self, nome, idade):
        self.nome = nome
        self.idade = idade
        self.pai = ""
        self.mae = ""

    def getNome(self):
        return self.nome

    def getIdade(self):
        return self.idade

    def setPai(self, pai):
        self.pai = pai

    def setMae(self, pessoa):
        self.mae = pessoa

    def imprimir(self):
        print("\nArvore Genealogica")

        print(f"\n{self.nome} tem {self.idade} anos de idade \ne é filho de")

        print(f"\n{self.mae.getNome()} que tem {self.mae.getIdade()} anos de idade \ne é casada com")

        print(f"\n{self.pai.getNome()} que tem {self.pai.getIdade()}  anos de idade")
