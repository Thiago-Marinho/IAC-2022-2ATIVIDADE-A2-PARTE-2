from Pessoa import Pessoa


class arvoreGenealogica:
    def __init__(self):

        nome = input("informe seu nome: ")
        idade = input("informe sua idade: ")
        pessoa = Pessoa(nome, idade)

        nomePai = input("\ninforme o nome do pai: ")
        idadePai = input("informe a idade do pai: ")


        pessoa.setPai(Pessoa(nomePai, idadePai))

        nomeMae = input("\ninforme o nome da mãe: ")
        idadeMae = input("informe a idade da mãe: ")

        
        pessoa.setMae(Pessoa(nomeMae, idadeMae))

        pessoa.imprimir()

