class Livro:
    def __init__(self, codLivro, autor, titulo):
        self.codLivro = codLivro
        self.autor = autor
        self.titulo = titulo