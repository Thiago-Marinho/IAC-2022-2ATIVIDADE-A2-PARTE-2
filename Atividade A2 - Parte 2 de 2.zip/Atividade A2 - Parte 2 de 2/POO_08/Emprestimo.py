from datetime import date

class Emprestimo:
    def __init__(self, pessoa):
        self.dataEmprestimo = date.today()
        self.dataDevolucao = ""
        self.livros = []
        self.pessoa = pessoa

    def adicionarLivro(self, livro):
        self.livros.append(livro)
