from Agenda import Agenda

Agenda.adicionaContatoAgenda(("Anderson", "67 99888-7569"))
Agenda.adicionaContatoAgenda(("José", "67 95695-9555"))
Agenda.adicionaContatoAgenda(("Marta", "67 97563-9555"))
Agenda.adicionaContatoAgenda(("Paula", "67 93356-1033"))

for contato in Agenda.visualizarContatos(Agenda):
    print(contato)

