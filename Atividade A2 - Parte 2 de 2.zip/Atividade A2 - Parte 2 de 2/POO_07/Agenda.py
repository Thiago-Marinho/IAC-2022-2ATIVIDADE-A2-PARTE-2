from Contato import Contato

class Agenda:
    global contatos
    contatos = []

    def visualizarContatos(self):
        return contatos

    def adicionaContatoAgenda(contato: Contato):
        contatos.append(contato)